import React, { useEffect, useMemo, useRef, useState } from "react";
// Wallet adapter hooks and components for multi-wallet support
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { v4 as uuidv4 } from "uuid";

/**
 * PUSH — Skate-to-Earn (Solana) — Launch-Ready (devnet)
 * - Wallet connect via Phantom (window.solana)
 * - SIWS (sign-in-with-solana) challenge & verify
 * - Airdrop registration (wallet + email + twitter + referral)
 * - Off-chain PUSH Points with serverless anti-cheat checks
 * - Leaderboard
 * - NFT Board mint: stub button calls /api/nft/mint (wire Metaplex later)
 */

const API = (path) => `${window.location.origin}${path}`;
const isPreview = () => typeof window !== "undefined" && window.location.hostname.includes("chatgpt");

const metersToKm = (m) => m / 1000;
const secondsToHMS = (s) => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return [h, m, sec].map((v) => String(v).padStart(2, "0")).join(":");
};

const randomId = () => Math.random().toString(36).slice(2, 10);

function createDemoBoard(rarity = "Common") {
  const rarities = {
    Common: { speed: [0.9, 1.1], control: [0.9, 1.1], luck: [0.9, 1.1], dura: [0.9, 1.1] },
    Uncommon: { speed: [1.05, 1.2], control: [1.05, 1.2], luck: [1.05, 1.2], dura: [1.05, 1.2] },
    Rare: { speed: [1.15, 1.35], control: [1.15, 1.35], luck: [1.15, 1.35], dura: [1.15, 1.35] },
    Epic: { speed: [1.3, 1.55], control: [1.3, 1.55], luck: [1.3, 1.55], dura: [1.3, 1.55] },
    Legendary: { speed: [1.5, 1.8], control: [1.5, 1.8], luck: [1.5, 1.8], dura: [1.5, 1.8] },
  };
  const pick = (min, max) => +(min + Math.random() * (max - min)).toFixed(2);
  const r = rarities[rarity] || rarities.Common;
  return {
    id: randomId(),
    name: `${rarity} Deck #${Math.floor(Math.random() * 9999)}`,
    rarity,
    lvl: 1,
    stats: {
      speed: pick(...r.speed),
      control: pick(...r.control),
      luck: pick(...r.luck),
      durability: pick(...r.dura),
    },
  };
}

const loadLS = (k, def) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } };
const saveLS = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };

export default function App() {
  const [wallet, setWallet] = useState(() => loadLS("push_wallet", { demo: true, address: "" }));
  const [session, setSession] = useState(() => loadLS("push_session", null)); // server-issued JWT

  const [boards, setBoards] = useState(() => loadLS("push_boards", [
    createDemoBoard("Common"),
    createDemoBoard("Uncommon"),
    createDemoBoard("Rare"),
  ]));
  const [equippedId, setEquippedId] = useState(() => loadLS("push_equipped", null));
  const equipped = useMemo(() => boards.find((b) => b.id === equippedId) || boards[0], [boards, equippedId]);

  const [rideActive, setRideActive] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [meters, setMeters] = useState(0);
  const [energy, setEnergy] = useState(() => loadLS("push_energy", 5));
  const [earnPts, setEarnPts] = useState(0);

  const [demoMode, setDemoMode] = useState(true);
  const [tab, setTab] = useState("ride"); // ride | airdrop | leaderboard | market

  // Use the wallet adapter hook to access the currently connected wallet.
  const { publicKey, connected, signMessage } = useWallet();

  // When the wallet connection changes, update the local wallet state.
  useEffect(() => {
    if (connected && publicKey) {
      setWallet({ demo: false, address: publicKey.toString() });
    } else {
      setWallet({ demo: true, address: "" });
    }
  }, [connected, publicKey]);

  const geoWatchId = useRef(null);
  const lastPos = useRef(null);
  const simTick = useRef(0);

  useEffect(() => saveLS("push_boards", boards), [boards]);
  useEffect(() => saveLS("push_equipped", equippedId), [equippedId]);
  useEffect(() => saveLS("push_energy", energy), [energy]);
  useEffect(() => saveLS("push_wallet", wallet), [wallet]);
  useEffect(() => saveLS("push_session", session), [session]);

  useEffect(() => { if (!rideActive) return; const iv = setInterval(() => setSeconds((s) => s + 1), 1000); return () => clearInterval(iv); }, [rideActive]);

  useEffect(() => {
    if (!rideActive) return;

    setEnergy((e) => (e > 0 ? +(e - 1 / 300).toFixed(3) : 0));
    const boardSpeed = equipped?.stats?.speed ?? 1;

    const pointsPerSecBase = 0.6;
    const paceMultiplier = (speed) => {
      if (!speed || Number.isNaN(speed)) return 0.3;
      if (speed < 6) return 0.6 * (speed / 6);
      if (speed > 25) return 0.6 * (25 / speed);
      return 1 + (speed - 6) / 28;
    };

    if (!demoMode && "geolocation" in navigator) {
      if (geoWatchId.current == null) {
        geoWatchId.current = navigator.geolocation.watchPosition(
          (pos) => {
            const { latitude, longitude } = pos.coords;
            if (lastPos.current) {
              const dist = haversine(lastPos.current, { latitude, longitude });
              setMeters((m) => m + dist);
              const speedKmh = (dist / 1000) * 3600;
              const energyMult = Math.max(0.25, Math.min(1, energy / 5));
              const perSec = pointsPerSecBase * boardSpeed * paceMultiplier(speedKmh) * energyMult;
              setEarnPts((p) => p + perSec);
            }
            lastPos.current = { latitude, longitude };
          },
          () => setDemoMode(true),
          { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
        );
      }
    } else {
      const iv = setInterval(() => {
        simTick.current += 1;
        const speedKmh = 10 + Math.sin(simTick.current / 10) * 5;
        const dist = (speedKmh * 1000) / 3600;
        setMeters((m) => m + dist);
        const energyMult = Math.max(0.25, Math.min(1, energy / 5));
        const perSec = pointsPerSecBase * boardSpeed * paceMultiplier(speedKmh) * energyMult;
        setEarnPts((p) => p + perSec);
      }, 1000);
      return () => clearInterval(iv);
    }

    return () => {
      if (geoWatchId.current != null) {
        navigator.geolocation.clearWatch(geoWatchId.current);
        geoWatchId.current = null;
        lastPos.current = null;
      }
    };
  }, [rideActive, demoMode, equipped, energy]);

  const km = metersToKm(meters);
  const avgKmh = seconds > 0 ? (km / (seconds / 3600)) : 0;

  async function connectWallet() {
    try {
      const provider = window?.solana;
      if (provider?.isPhantom) {
        const resp = await provider.connect();
        const address = resp.publicKey.toString();
        setWallet({ demo: false, address });
      } else {
        alert("Phantom not detected. Install Phantom or use mobile with Phantom.");
        setWallet({ demo: true, address: "" });
      }
    } catch { alert("Wallet connection cancelled."); }
  }

  async function siws() {
    if (!wallet.address) return alert("Connect wallet first.");
    const r1 = await fetch(API("/api/siws-challenge?address=" + wallet.address));
    const { message } = await r1.json();
    const enc = new TextEncoder();
    // Use the wallet adapter's signMessage for SIWS; ensure the wallet supports it
    if (!signMessage) return alert("Wallet does not support message signing.");
    const signed = await signMessage(enc.encode(message));
    const sigB64 = btoa(String.fromCharCode(...signed));
    const r2 = await fetch(API("/api/siws-verify"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ address: wallet.address, message, signature: sigB64 }),
      credentials: "include",
    });
    if (!r2.ok) return alert("SIWS verification failed.");
    const data = await r2.json();
    setSession(data);
    alert("Signed in.");
  }

  function startRide() { if (energy <= 0 && !confirm("Energy is empty. Continue in low-earn mode?")) return; setRideActive(true); }
  function stopRide() { setRideActive(false); }
  function resetRide() { setRideActive(false); setSeconds(0); setMeters(0); setEarnPts(0); }

  async function claimPoints() {
    if (!session) return alert("Sign-in required.");
    if (!wallet.address) return alert("Wallet required.");
    const proof = {
      wallet: wallet.address,
      distanceMeters: meters,
      seconds,
      avgKmh,
      energyUsed: 5 - energy,
      device: navigator.userAgent.slice(0, 120),
      startedAt: Date.now() - seconds * 1000,
      endedAt: Date.now(),
    };
    const enc = new TextEncoder();
    // Sign the ride proof using the connected wallet via the wallet adapter
    if (!signMessage) return alert("Wallet does not support message signing.");
    const signed = await signMessage(enc.encode(JSON.stringify(proof)));
    const sigB64 = btoa(String.fromCharCode(...signed));
    const r = isPreview()
      ? { ok: true, json: async () => ({ delta: Math.round(earnPts), total: Math.round(earnPts) }) }
      : await fetch(API("/api/points/claim"), {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.token || ""}` },
          body: JSON.stringify({ proof, signature: sigB64 }),
        });
    if (!r.ok) return alert("Claim failed.");
    const data = await r.json();
    alert(`Claimed +${data.delta} PUSH Points. Total: ${data.total}`);
    resetRide();
  }

  const [airdrop, setAirdrop] = useState({ email: "", twitter: "", ref: "" });
  async function registerAirdrop() {
    if (!session) return alert("Sign-in required.");
    const payload = { email: airdrop.email, twitter: airdrop.twitter, ref: airdrop.ref };
    const r = isPreview()
      ? { ok: true, json: async () => ({ ok: true }) }
      : await fetch(API("/api/airdrop/register"), {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.token || ""}` },
          body: JSON.stringify(payload),
        });
    if (!r.ok) return alert("Airdrop registration failed.");
    alert("Registered for airdrop. Watch @pushskate for updates.");
  }

  // Signup state and handler for collecting customer signup data
  const [signup, setSignup] = useState({ name: "", email: "" });
  async function registerSignup() {
    if (!wallet.address) return alert("Wallet required.");
    const payload = { wallet: wallet.address, name: signup.name, email: signup.email };
    const r = isPreview()
      ? { ok: true, json: async () => ({ ok: true }) }
      : await fetch(API("/api/signup-register"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
    if (!r.ok) return alert("Signup failed.");
    alert("Signed up successfully.");
  }

  const [lb, setLb] = useState([]);
  async function loadLeaderboard() {
    const r = isPreview()
      ? { ok: true, json: async () => ({ items: [] }) }
      : await fetch(API("/api/leaderboard"));
    if (!r.ok) return;
    const data = await r.json();
    setLb(data.items || []);
  }
  useEffect(() => { if (tab === "leaderboard") loadLeaderboard(); }, [tab]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-zinc-950 via-zinc-900 to-black text-zinc-100">
      <header className="sticky top-0 z-30 backdrop-blur bg-black/30 border-b border-white/10">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-400 to-emerald-500 shadow-lg shadow-emerald-500/20 grid place-items-center text-black font-black">🛹</div>
            <div>
              <div className="text-xl font-semibold tracking-tight">PUSH</div>
              <div className="text-[11px] text-zinc-400 -mt-1">Skate‑to‑Earn • Solana (devnet)</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-3 text-sm">
            <NavBtn onClick={() => setTab("ride")} active={tab === "ride"}>Ride</NavBtn>
            <NavBtn onClick={() => setTab("airdrop")} active={tab === "airdrop"}>Airdrop</NavBtn>
            <NavBtn onClick={() => setTab("signup")} active={tab === "signup"}>Sign Up</NavBtn>
            <NavBtn onClick={() => setTab("leaderboard")} active={tab === "leaderboard"}>Leaderboard</NavBtn>
            <NavBtn onClick={() => setTab("market")} active={tab === "market"}>Boards</NavBtn>
          </nav>
          <div className="flex items-center gap-2">
            {/* The WalletMultiButton automatically handles connecting/disconnecting any supported Solana wallet */}
            <WalletMultiButton className="rounded-xl px-3 py-2 text-sm" />
            <button onClick={siws} className="rounded-xl px-3 py-2 bg-emerald-500 hover:bg-emerald-400 text-black text-sm">Sign In</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        {tab === "ride" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <section className="lg:col-span-2">
              <Panel>
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold">Ride</h2>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-zinc-400">Demo Mode</span>
                    <Toggle on={demoMode} setOn={setDemoMode} />
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-3">
                  <Stat label="Time" value={secondsToHMS(seconds)} />
                  <Stat label="Distance" value={`${metersToKm(meters).toFixed(2)} km`} />
                  <Stat label="Avg Speed" value={`${avgKmh.toFixed(1)} km/h`} />
                </div>

                <div className="mt-5 grid grid-cols-3 gap-3">
                  <Stat label="PUSH Points (est.)" value={`${earnPts.toFixed(0)} pts`} accent />
                  <Stat label="Energy" value={`${Math.max(0, energy).toFixed(2)} / 5`} />
                  <Stat label="Equipped" value={equipped?.name || "-"} />
                </div>

                <div className="mt-6 flex items-center gap-3">
                  {!rideActive ? (
                    <button onClick={startRide} className="flex-1 rounded-xl py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold">▶ Start Ride</button>
                  ) : (
                    <button onClick={stopRide} className="flex-1 rounded-xl py-3 bg-rose-500 hover:bg-rose-400 text-black font-semibold">■ Stop Ride</button>
                  )}
                  <button onClick={resetRide} className="rounded-xl px-4 py-3 bg-white/10 hover:bg-white/20 border border-white/10">Reset</button>
                  <button onClick={claimPoints} className="rounded-xl px-4 py-3 bg-cyan-500 hover:bg-cyan-400 text-black">Claim Points</button>
                </div>

                <div className="mt-6 text-xs text-zinc-400">Earning scales with speed window (≈6–25 km/h), board stats, and remaining energy.</div>
              </Panel>
            </section>

            <section className="space-y-6">
              <Panel title="Equipped Board">{equipped ? <BoardCard board={equipped} equipped onEquip={()=>{}} /> : <div>No board.</div>}</Panel>
              <Panel title={`Your Boards (${boards.length})`}>
                <div className="grid grid-cols-1 gap-3">
                  {boards.map((b) => <BoardCard key={b.id} board={b} equipped={b.id===equippedId} onEquip={() => setEquippedId(b.id)} />)}
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <button onClick={() => setBoards([createDemoBoard(), ...boards])} className="rounded-xl px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/10">Mint Demo Board</button>
                  <button onClick={() => alert("Mint via /api/nft/mint (Metaplex) after configuring server).")} className="rounded-xl px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black">Mint on Solana</button>
                </div>
              </Panel>
            </section>
          </div>
        )}

        {tab === "airdrop" && (
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Panel title="Join the PUSH Airdrop">
              <p className="text-sm text-zinc-300">Connect wallet, sign in, and register. Complete rides to earn PUSH Points—convertible at TGE per the airdrop rules.</p>
              <div className="mt-4 grid gap-3">
                <input className="rounded-xl bg-white/10 border border-white/10 px-3 py-2" placeholder="Email" value={airdrop.email} onChange={(e)=>setAirdrop(v=>({...v, email: e.target.value}))} />
                <input className="rounded-xl bg-white/10 border border-white/10 px-3 py-2" placeholder="Twitter / X (optional)" value={airdrop.twitter} onChange={(e)=>setAirdrop(v=>({...v, twitter: e.target.value}))} />
                <input className="rounded-xl bg-white/10 border border-white/10 px-3 py-2" placeholder="Referral code (optional)" value={airdrop.ref} onChange={(e)=>setAirdrop(v=>({...v, ref: e.target.value}))} />
                <button onClick={()=>registerAirdrop()} className="rounded-xl px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold">Register</button>
              </div>
              <p className="text-[11px] text-zinc-500 mt-3">By registering, you agree to our Terms & that this is not financial advice. Airdrop eligibility may be restricted in some regions.</p>
            </Panel>
            <Panel title="Refer friends (boost)">
              <p className="text-sm text-zinc-300">After registering, get your referral code in your profile to earn bonus points when friends ride.</p>
              <ul className="text-sm mt-2 list-disc list-inside text-zinc-300 space-y-1">
                <li>+100 pts per verified signup</li>
                <li>+10% of their first 7 days’ ride points</li>
              </ul>
            </Panel>
          </section>
        )}

        {tab === "signup" && (
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Panel title="Sign Up">
              <p className="text-sm text-zinc-300">Provide your name and email to join our community.</p>
              <div className="mt-4 grid gap-3">
                <input className="rounded-xl bg-white/10 border border-white/10 px-3 py-2" placeholder="Name" value={signup.name} onChange={(e) => setSignup(v => ({ ...v, name: e.target.value }))} />
                <input className="rounded-xl bg-white/10 border border-white/10 px-3 py-2" placeholder="Email" value={signup.email} onChange={(e) => setSignup(v => ({ ...v, email: e.target.value }))} />
                <button onClick={() => registerSignup()} className="rounded-xl px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold">Sign Up</button>
              </div>
            </Panel>
          </section>
        )}

        {tab === "leaderboard" && (
          <section>
            <Panel title="Leaderboard">
              <table className="w-full text-sm">
                <thead className="text-zinc-400"><tr><th className="text-left py-2">#</th><th className="text-left">Wallet</th><th className="text-right">Points</th></tr></thead>
                <tbody>
                  {lb.map((row, i) => (
                    <tr key={row.address} className="border-t border-white/5">
                      <td className="py-2">{i+1}</td>
                      <td>{row.address.slice(0,6)}…{row.address.slice(-6)}</td>
                      <td className="text-right">{row.points}</td>
                    </tr>
                  ))}
                  {lb.length === 0 && <tr><td colSpan="3" className="py-6 text-center text-zinc-500">No entries yet.</td></tr>}
                </tbody>
              </table>
            </Panel>
          </section>
        )}

        {tab === "market" && (
          <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Panel title="Marketplace (Soon)">
              <div className="text-sm text-zinc-400">List/buy/sell Boards with royalties; devnet first. Anti-cheat, Geo events, Streaks, Crews.</div>
              <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
                <Chip>Royalties</Chip><Chip>Anti‑cheat</Chip><Chip>Geo‑events</Chip>
                <Chip>Crews</Chip><Chip>Streaks</Chip><Chip>Leaderboards</Chip>
              </div>
            </Panel>
            <Panel title="Faucet">
              <a className="text-sm underline text-emerald-300" href="https://faucet.solana.com/" target="_blank" rel="noreferrer">Get devnet SOL</a>
            </Panel>
          </section>
        )}
      </main>

      <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs text-zinc-500">
        © {new Date().getFullYear()} PUSH (devnet). Not financial advice. Points are off-chain; airdrop subject to eligibility.
      </footer>
    </div>
  );
}

function NavBtn({ children, active, onClick }) { return <button onClick={onClick} className={`px-3 py-1.5 rounded-lg border ${active?'border-emerald-400 bg-emerald-400/10':'border-white/10 bg-white/5'} hover:bg-white/10`}>{children}</button>; }
function Panel({ children, title }) { return (<div className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-inner shadow-black/20">{title && <h3 className="text-sm font-semibold text-zinc-200 mb-3">{title}</h3>}{children}</div>); }
function Stat({ label, value, accent }) { return (<div className={`rounded-2xl border border-white/10 p-4 bg-gradient-to-br ${accent ? "from-emerald-500/20 to-cyan-500/10" : "from-white/5 to-white/0"}`}><div className="text-xs text-zinc-400">{label}</div><div className={`text-xl font-semibold mt-1 ${accent ? "text-emerald-300" : "text-zinc-100"}`}>{value}</div></div>); }
function Chip({ children }) { return <span className="px-3 py-1 rounded-full bg-white/10 border border-white/10 text-zinc-200 inline-flex items-center justify-center">{children}</span>; }
function Toggle({ on, setOn }) { return (<button onClick={() => setOn(!on)} className={`h-6 w-11 rounded-full border border-white/10 p-0.5 transition ${on ? "bg-emerald-500" : "bg-white/10"}`} aria-pressed={on}><span className={`block h-5 w-5 rounded-full bg-white transition ${on ? "translate-x-5" : "translate-x-0"}`}></span></button>); }
function BoardCard({ board, onEquip, equipped }) {
  const rColors = { Common: "from-zinc-600 to-zinc-800", Uncommon: "from-emerald-600 to-emerald-800", Rare: "from-indigo-600 to-indigo-800", Epic: "from-fuchsia-600 to-fuchsia-800", Legendary: "from-amber-500 to-orange-700" };
  return (
    <div className="rounded-xl border border-white/10 p-3 bg-white/5">
      <div className="flex items-center gap-3">
        <div className={`h-12 w-12 rounded-lg bg-gradient-to-br ${rColors[board.rarity]} grid place-items-center text-black text-lg font-black`}>🛹</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <div className="font-semibold truncate">{board.name}</div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 border border-white/10">Lv {board.lvl}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 border border-white/10">{board.rarity}</span>
          </div>
          <div className="mt-1 text-xs text-zinc-400 grid grid-cols-4 gap-2">
            <span>Speed <b className="text-zinc-200">×{board.stats.speed}</b></span>
            <span>Control <b className="text-zinc-200">×{board.stats.control}</b></span>
            <span>Luck <b className="text-zinc-200">×{board.stats.luck}</b></span>
            <span>Durab. <b className="text-zinc-200">×{board.stats.durability}</b></span>
          </div>
        </div>
        {!equipped && <button onClick={onEquip} className="rounded-lg px-3 py-2 bg-white/10 hover:bg-white/20 border border-white/10 text-sm">Equip</button>}
        {equipped && <span className="text-xs text-emerald-300">Equipped</span>}
      </div>
    </div>
  );
}
// Removed duplicate metersToKm function definition. A single metersToKm helper is defined at the top of this file.
// function metersToKm(m) { return m / 1000; }
function haversine(a, b) {
  const R = 6371e3;
  const φ1 = (a.latitude * Math.PI) / 180;
  const φ2 = (b.latitude * Math.PI) / 180;
  const Δφ = ((b.latitude - a.latitude) * Math.PI) / 180;
  const Δλ = ((b.longitude - a.longitude) * Math.PI) / 180;
  const s = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
  return R * c;
}
